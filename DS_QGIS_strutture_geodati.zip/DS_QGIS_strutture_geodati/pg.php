<?php
// Header per evitare che i bot facciano girare lo script inutilmente
header("X-Robots-Tag: noindex, nofollow", true);
// Header per dire al client che il formato della pagina è JSON 
header('Content-type: application/json');
// Mi collego al DB
$dbconn = pg_connect("host=localhost dbname=geodatabaseCorso user=postgres password=postgres")
    or die('Non sono riuscito a collegarmi: ' . pg_last_error());
// Testo con la query da mandare a PostGRESQL 
$query = 'SELECT ST_AsGeoJSON(t1.*) 
FROM 
(SELECT id, ST_Transform(geom, 4326) FROM geodati.antenne_clc) t1';
// Faccio girare la query
$result = pg_query($query) or die('Query non corretta: ' . pg_last_error());

// Inizio a scrivere i dati sulla pagina... JSON inizia tra parentesi graffe { XXXX }
echo	'{ "type": "FeatureCollection", "features": [';
// Creo un array vuoto
$res=Array();	
// Inizio interazione (loop) su tutte le righe
while ($line = pg_fetch_array($result)) { 
// Aggiungo riga al Array creato prima
   $res[] = $line[0] ; 
}
// Concateno le righe unendole con una virgola e scrivo su pagina
echo implode(",", $res);
// Termino chiudendo le parentesi\
echo	'] }';
// Free resultset
pg_free_result($result);

// Closing connection
pg_close($dbconn);
// Finito la pagina
?>